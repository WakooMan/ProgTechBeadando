package tictactoe.gamecontrol;

/**
 * Enum type for the match result.
 */
public enum MatchResult {
    Ongoing,
    X,
    O,
    Draw
}
